# Géométrie vectorielle et produit scalaire

> Cours approfondi — Première spécialité mathématiques (niveau cible MPSI)

---

## Avertissement

Ce cours couvre le programme de Première (produit scalaire, géométrie repérée) mais le pousse au niveau attendu d'un futur MPSI : définitions formalisées, démonstrations complètes (y compris hors-programme), structure d'espace vectoriel sous-jacente, méthodes de résolution typées, pièges classiques. Tout théorème utilisé est explicitement nommé et ses hypothèses vérifiées. Les démonstrations marquées $(\star)$ sont hors-programme strict mais accessibles et formatrices.

---

## Table des matières

1. [Vecteurs : du concret à la structure](#1-vecteurs--du-concret-à-la-structure)
2. [Produit scalaire : quatre définitions équivalentes](#2-produit-scalaire--quatre-définitions-équivalentes)
3. [Orthogonalité](#3-orthogonalité)
4. [Formule d'Al-Kashi](#4-formule-dal-kashi)
5. [La transformation $\vec{MA}\cdot\vec{MB}$](#5-la-transformation-vecmacdotvecmb)
6. [Géométrie repérée](#6-géométrie-repérée)
7. [Méthodes consolidées](#7-méthodes-consolidées)
8. [Pièges et erreurs récurrentes](#8-pièges-et-erreurs-récurrentes)
9. [Théorèmes à savoir réciter (mode colle)](#9-théorèmes-à-savoir-réciter-mode-colle)
10. [Ouvertures vers la MPSI](#10-ouvertures-vers-la-mpsi)
11. [Synthèse](#11-synthèse)

---

## 1. Vecteurs : du concret à la structure

### 1.1. Intuition et trois points de vue

Un vecteur du plan ne s'identifie pas à un point. C'est une *classe de bipoints équipollents* : $(A,B)$ et $(C,D)$ représentent le même vecteur $\vec{u}$ ssi $ABDC$ est un parallélogramme (éventuellement aplati). Trois points de vue coexistent :

1. **Géométrique** : flèche caractérisée par direction, sens, norme.
2. **Algébrique** : couple de coordonnées dans une base.
3. **Fonctionnel** : translation du plan ($M\mapsto M+\vec{u}$).

La force du calcul vectoriel : passer librement d'un point de vue à l'autre.

> **Définition 1.1 (Vecteur du plan).** On note $\mathscr{P}$ le plan affine euclidien. Pour $A,B\in\mathscr{P}$, le *bipoint* $(A,B)$ représente le vecteur $\vec{AB}$. Deux bipoints $(A,B)$ et $(C,D)$ définissent le même vecteur ssi $ABDC$ est un parallélogramme, i.e. ssi $\vec{AB}=\vec{CD}$, i.e. ssi le milieu de $[AD]$ est aussi celui de $[BC]$.

**Vocabulaire :**
- Le **vecteur nul** $\vec{0}$ est l'unique vecteur tel que $\vec{AA}=\vec{0}$ pour tout $A$. Il n'a pas de direction.
- Pour $\vec{u}\neq\vec{0}$, sa **direction** est l'ensemble des droites $(AB)$ avec $\vec{AB}=\vec{u}$ ; toutes sont parallèles.
- Sa **norme** $\|\vec{u}\|$ est la longueur $AB$ pour n'importe quel représentant.

### 1.2. Opérations et structure d'espace vectoriel

> **Définition 1.2 (Somme et multiplication par un scalaire).** Soient $\vec{u}=\vec{AB}$, $\vec{v}=\vec{BC}$ et $\lambda\in\mathbb{R}$.
>
> $$\vec{u}+\vec{v} := \vec{AC} \qquad\text{(relation de Chasles)}$$
>
> $\lambda\cdot\vec{u}$ est le vecteur de même direction que $\vec{u}$, de norme $|\lambda|\cdot\|\vec{u}\|$, de même sens si $\lambda>0$, de sens opposé si $\lambda<0$, nul si $\lambda=0$ ou $\vec{u}=\vec{0}$.

> **Théorème 1.3 (Structure d'espace vectoriel sur $\mathbb{R}$).** L'ensemble $V$ des vecteurs du plan, muni de $+$ et $\cdot$, vérifie pour tous $\vec{u},\vec{v},\vec{w}\in V$ et $\lambda,\mu\in\mathbb{R}$ :
>
> 1. **(EV1)** $(\vec{u}+\vec{v})+\vec{w}=\vec{u}+(\vec{v}+\vec{w})$ — associativité
> 2. **(EV2)** $\vec{u}+\vec{v}=\vec{v}+\vec{u}$ — commutativité
> 3. **(EV3)** $\vec{u}+\vec{0}=\vec{u}$ — neutre
> 4. **(EV4)** $\vec{u}+(-\vec{u})=\vec{0}$ — opposé
> 5. **(EV5)** $\lambda(\vec{u}+\vec{v})=\lambda\vec{u}+\lambda\vec{v}$
> 6. **(EV6)** $(\lambda+\mu)\vec{u}=\lambda\vec{u}+\mu\vec{u}$
> 7. **(EV7)** $(\lambda\mu)\vec{u}=\lambda(\mu\vec{u})$
> 8. **(EV8)** $1\cdot\vec{u}=\vec{u}$
>
> On dit que $V$ est un *$\mathbb{R}$-espace vectoriel*.

> ⚠️ **Pourquoi c'est important.** Cette structure est l'ossature de toute l'algèbre linéaire à venir en MPSI. Tout ce que tu démontres sur les vecteurs du plan en utilisant uniquement (EV1)–(EV8) sera vrai dans $\mathbb{R}^n$, dans l'espace des polynômes, dans l'espace des fonctions, etc. **Apprendre à raisonner abstraitement dès maintenant t'évitera de tout réapprendre.**

### 1.3. Colinéarité, bases, coordonnées

> **Définition 1.4 (Colinéarité).** $\vec{u}$ et $\vec{v}$ sont *colinéaires* ssi $\exists\lambda\in\mathbb{R},\ \vec{v}=\lambda\vec{u}$ *ou* $\exists\mu\in\mathbb{R},\ \vec{u}=\mu\vec{v}$.

> ⚠️ **Piège — Subtilité avec le vecteur nul.** $\vec{0}$ est colinéaire à *tout* vecteur ($\vec{0}=0\cdot\vec{u}$). Quand on dit « $\vec{u}$ et $\vec{v}$ non colinéaires », on inclut implicitement $\vec{u}\neq\vec{0}$ et $\vec{v}\neq\vec{0}$.

> **Définition 1.5 (Base du plan).** Un couple $(\vec{i},\vec{j})$ de vecteurs est une *base* de $V$ ssi $\vec{i}$ et $\vec{j}$ sont non colinéaires.

> **Théorème 1.6 (Décomposition unique dans une base).** Soit $(\vec{i},\vec{j})$ une base. Pour tout $\vec{u}\in V$, il existe un unique couple $(x,y)\in\mathbb{R}^2$ tel que $\vec{u}=x\vec{i}+y\vec{j}$. On dit que $(x,y)$ sont les *coordonnées* de $\vec{u}$ dans la base $(\vec{i},\vec{j})$.

**Démonstration $(\star)$.**

*Existence.* On admet (résultat de géométrie affine) que tout vecteur du plan se décompose comme somme de deux vecteurs colinéaires respectivement à deux directions distinctes données.

*Unicité.* Supposons $x\vec{i}+y\vec{j}=x'\vec{i}+y'\vec{j}$. Alors $(x-x')\vec{i}=(y'-y)\vec{j}$. Si $x\neq x'$, alors $\vec{i}=\frac{y'-y}{x-x'}\vec{j}$, donc $\vec{i}$ et $\vec{j}$ sont colinéaires : contradiction. Donc $x=x'$, puis $(y-y')\vec{j}=\vec{0}$, et comme $\vec{j}\neq\vec{0}$, $y=y'$. ∎

> **Proposition 1.7 (Critère de colinéarité par déterminant).** Dans une base $(\vec{i},\vec{j})$, soient $\vec{u}=(x,y)$ et $\vec{v}=(x',y')$. Alors :
>
> $$\vec{u}\text{ et }\vec{v}\text{ colinéaires}\iff xy'-x'y=0.$$
>
> La quantité $\det(\vec{u},\vec{v}):=xy'-x'y$ s'appelle le *déterminant* de $(\vec{u},\vec{v})$.

**Démonstration.**

$(\Rightarrow)$ Si $\vec{v}=\lambda\vec{u}$, alors $x'=\lambda x$, $y'=\lambda y$, donc $xy'-x'y=x(\lambda y)-(\lambda x)y=0$. Symétriquement si $\vec{u}=\mu\vec{v}$.

$(\Leftarrow)$ Supposons $xy'-x'y=0$.
- Si $\vec{u}=\vec{0}$, alors $\vec{u}$ est colinéaire à $\vec{v}$.
- Sinon $x\neq 0$ ou $y\neq 0$. Supposons $x\neq 0$. Alors $y'=x'y/x$, donc $\vec{v}=x'\vec{i}+\frac{x'y}{x}\vec{j}=\frac{x'}{x}(x\vec{i}+y\vec{j})=\frac{x'}{x}\vec{u}$. ∎

---

## 2. Produit scalaire : quatre définitions équivalentes

### 2.1. Pourquoi un nouveau outil ?

Le calcul vectoriel sait gérer le parallélisme et le barycentrique. Il ne sait pas, de façon native, exprimer *l'orthogonalité* ni les *longueurs*. Le produit scalaire est l'outil qui code ces deux notions dans une unique opération bilinéaire et symétrique.

### 2.2. Quatre définitions, un seul objet

> **Définition 2.1 (Produit scalaire — 4 formes).** Soient $\vec{u},\vec{v}$ deux vecteurs du plan. On définit $\vec{u}\cdot\vec{v}\in\mathbb{R}$ par l'une (n'importe laquelle) des formules suivantes, équivalentes entre elles :
>
> **(F1) Cosinus.** Si $\vec{u}\neq\vec{0}$ et $\vec{v}\neq\vec{0}$,
> $$\vec{u}\cdot\vec{v}=\|\vec{u}\|\cdot\|\vec{v}\|\cdot\cos(\widehat{\vec{u},\vec{v}}),$$
> et $\vec{u}\cdot\vec{v}=0$ si l'un des deux est nul.
>
> **(F2) Projection orthogonale.** Soit $\vec{v}'$ le projeté orthogonal de $\vec{v}$ sur la droite vectorielle dirigée par $\vec{u}$. Alors
> $$\vec{u}\cdot\vec{v}=\begin{cases}+\|\vec{u}\|\cdot\|\vec{v}'\| & \text{si }\vec{v}'\text{ et }\vec{u}\text{ de même sens}\\ -\|\vec{u}\|\cdot\|\vec{v}'\| & \text{si sens opposé}\\ 0 & \text{si }\vec{v}'=\vec{0}\end{cases}$$
>
> **(F3) Coordonnées en BON.** Si $\vec{u}=(x,y)$ et $\vec{v}=(x',y')$ dans une base orthonormée,
> $$\vec{u}\cdot\vec{v}=xx'+yy'.$$
>
> **(F4) Polarisation par les normes.**
> $$\vec{u}\cdot\vec{v}=\tfrac{1}{2}\bigl(\|\vec{u}+\vec{v}\|^2-\|\vec{u}\|^2-\|\vec{v}\|^2\bigr).$$
> Variante symétrique :
> $$\vec{u}\cdot\vec{v}=\tfrac{1}{4}\bigl(\|\vec{u}+\vec{v}\|^2-\|\vec{u}-\vec{v}\|^2\bigr).$$

> **Théorème 2.2 (Équivalence des quatre définitions).** Les formules (F1), (F2), (F3), (F4) définissent toutes le même nombre réel.

**Démonstration (schéma F1⇔F2, F1⇒F4, F4⇒F3, F3⇒F1).**

**(F1)⇔(F2).** Soit $\theta=\widehat{\vec{u},\vec{v}}$. Par définition trigonométrique de la projection, $\|\vec{v}'\|=\|\vec{v}\|\cdot|\cos\theta|$, et le signe correspond au sens. Donc $\|\vec{u}\|\cdot\|\vec{v}\|\cos\theta = \pm\|\vec{u}\|\cdot\|\vec{v}'\|$, avec le bon signe.

**(F1)⇒(F4).** On part de $\|\vec{u}+\vec{v}\|^2=\|\vec{u}\|^2+\|\vec{v}\|^2+2\|\vec{u}\|\|\vec{v}\|\cos\theta$ (Al-Kashi, démontré plus bas indépendamment avec (F2)). En isolant le terme en $\cos$, on obtient (F4).

**(F4)⇒(F3).** En BON, $\|\vec{u}+\vec{v}\|^2=(x+x')^2+(y+y')^2$, $\|\vec{u}\|^2=x^2+y^2$, $\|\vec{v}\|^2=x'^2+y'^2$. On développe :

$$(x+x')^2+(y+y')^2-x^2-y^2-x'^2-y'^2 = 2xx'+2yy'.$$

On divise par $2$ : c'est (F3).

**(F3)⇒(F1).** Si $\vec{u}=(\|\vec{u}\|,0)$ (toujours possible en choisissant une BON où $\vec{i}=\vec{u}/\|\vec{u}\|$), alors $\vec{v}=(\|\vec{v}\|\cos\theta,\|\vec{v}\|\sin\theta)$. Donc $xx'+yy'=\|\vec{u}\|\cdot\|\vec{v}\|\cos\theta$. ∎

> 💡 **Lecture stratégique.** Chacune des quatre formules a sa zone d'efficacité :
> - **(F1)** — quand on connaît un angle.
> - **(F2)** — quand un projeté est facile à voir (perpendicularité dans la figure).
> - **(F3)** — en repère.
> - **(F4)** — quand on connaît trois normes.
>
> **Choisir la bonne formule, c'est l'essentiel d'un exercice.**

### 2.3. Propriétés algébriques fondamentales

> **Théorème 2.3 (Bilinéarité et symétrie).** Pour tous $\vec{u},\vec{v},\vec{w}\in V$ et $\lambda\in\mathbb{R}$ :
>
> - **(B1)** $\vec{u}\cdot\vec{v}=\vec{v}\cdot\vec{u}$ — symétrie
> - **(B2)** $(\vec{u}+\vec{v})\cdot\vec{w}=\vec{u}\cdot\vec{w}+\vec{v}\cdot\vec{w}$
> - **(B3)** $(\lambda\vec{u})\cdot\vec{v}=\lambda(\vec{u}\cdot\vec{v})$
> - **(B4)** Idem à droite par symétrie
> - **(B5)** $\vec{u}\cdot\vec{u}=\|\vec{u}\|^2\geq 0$
> - **(B6)** $\vec{u}\cdot\vec{u}=0\iff \vec{u}=\vec{0}$

**Démonstration (avec F3 en BON).**

(B1) $xx'+yy'=x'x+y'y$.
(B2) $(x_1+x_2)x_3+(y_1+y_2)y_3=x_1x_3+y_1y_3+x_2x_3+y_2y_3$.
(B3) $(\lambda x)x'+(\lambda y)y'=\lambda(xx'+yy')$.
(B5) $\vec{u}\cdot\vec{u}=x^2+y^2=\|\vec{u}\|^2$.
(B6) $x^2+y^2=0\iff x=y=0\iff \vec{u}=\vec{0}$. ∎

> ⚠️ **Piège — La bilinéarité n'est pas linéarité simple.**
> $$(\vec{u}+\vec{v})\cdot(\vec{u}+\vec{v})\neq \vec{u}\cdot\vec{u}+\vec{v}\cdot\vec{v}.$$
> Il y a un *double terme croisé* :
> $$(\vec{u}+\vec{v})\cdot(\vec{u}+\vec{v})=\vec{u}\cdot\vec{u}+2\vec{u}\cdot\vec{v}+\vec{v}\cdot\vec{v}.$$
> C'est l'analogue exact de $(a+b)^2=a^2+2ab+b^2$.

### 2.4. Identités de polarisation

> **Proposition 2.4 (Trois identités à connaître par cœur).**
>
> $$\|\vec{u}+\vec{v}\|^2 = \|\vec{u}\|^2+2\,\vec{u}\cdot\vec{v}+\|\vec{v}\|^2$$
>
> $$\|\vec{u}-\vec{v}\|^2 = \|\vec{u}\|^2-2\,\vec{u}\cdot\vec{v}+\|\vec{v}\|^2$$
>
> $$\|\vec{u}+\vec{v}\|^2+\|\vec{u}-\vec{v}\|^2 = 2\bigl(\|\vec{u}\|^2+\|\vec{v}\|^2\bigr) \quad\text{(identité du parallélogramme)}$$

**Démonstration.** On développe : $\|\vec{u}+\vec{v}\|^2=(\vec{u}+\vec{v})\cdot(\vec{u}+\vec{v})=\vec{u}\cdot\vec{u}+\vec{u}\cdot\vec{v}+\vec{v}\cdot\vec{u}+\vec{v}\cdot\vec{v}=\|\vec{u}\|^2+2\vec{u}\cdot\vec{v}+\|\vec{v}\|^2$ par (B1)–(B5). Idem pour le deuxième. Le troisième s'obtient en ajoutant les deux premiers. ∎

> 💡 **Interprétation géométrique.** La somme des carrés des diagonales d'un parallélogramme égale la somme des carrés des quatre côtés. C'est une identité *caractéristique* des espaces euclidiens (théorème de Jordan–von Neumann, hors-programme).

---

## 3. Orthogonalité

### 3.1. Caractérisation

> **Définition 3.1 (Orthogonalité).** $\vec{u}\perp\vec{v}\iff \vec{u}\cdot\vec{v}=0$.

> **Proposition 3.2 (Cohérence avec la géométrie).** Si $\vec{u}\neq\vec{0}$ et $\vec{v}\neq\vec{0}$, alors $\vec{u}\perp\vec{v}$ ssi l'angle $\widehat{\vec{u},\vec{v}}$ est droit.

**Démonstration.** Par (F1), $\vec{u}\cdot\vec{v}=\|\vec{u}\|\|\vec{v}\|\cos\theta=0\iff \cos\theta=0\iff \theta=\pm\pi/2$. ∎

> ⚠️ **Piège — Le vecteur nul.** Par convention, $\vec{0}\perp\vec{u}$ pour tout $\vec{u}$ (puisque $\vec{0}\cdot\vec{u}=0$). C'est cohérent avec la définition mais pas avec l'intuition « angle droit », parce que $\vec{0}$ n'a pas d'angle.

### 3.2. Théorème de Pythagore vectoriel

> **Théorème 3.3 (Pythagore vectoriel).**
> $$\vec{u}\perp\vec{v}\iff \|\vec{u}+\vec{v}\|^2=\|\vec{u}\|^2+\|\vec{v}\|^2.$$

**Démonstration.** Par polarisation, $\|\vec{u}+\vec{v}\|^2=\|\vec{u}\|^2+\|\vec{v}\|^2+2\vec{u}\cdot\vec{v}$. Donc égalité ssi $\vec{u}\cdot\vec{v}=0$, ssi $\vec{u}\perp\vec{v}$. ∎

> 💡 **Force de l'« ssi ».** On a une équivalence, pas seulement une implication. La réciproque de Pythagore est gratuite ici, alors qu'au collège elle demandait un argument séparé.

---

## 4. Formule d'Al-Kashi

> **Théorème 4.1 (Al-Kashi — loi des cosinus).** Soit $ABC$ un triangle. On note $a=BC$, $b=CA$, $c=AB$, et $\widehat{A}=\widehat{BAC}$. Alors :
> $$a^2 = b^2+c^2 - 2bc\cos\widehat{A}.$$

**Démonstration.** On part de $\vec{BC}=\vec{BA}+\vec{AC}=\vec{AC}-\vec{AB}$. Donc :

$$a^2 = \|\vec{BC}\|^2 = \|\vec{AC}-\vec{AB}\|^2$$

$$= \|\vec{AC}\|^2 - 2\,\vec{AC}\cdot\vec{AB} + \|\vec{AB}\|^2 \quad\text{(polarisation)}$$

$$= b^2 + c^2 - 2\,\vec{AC}\cdot\vec{AB}.$$

Or par (F1), $\vec{AC}\cdot\vec{AB}=\|\vec{AC}\|\|\vec{AB}\|\cos\widehat{A}=bc\cos\widehat{A}$. D'où le résultat. ∎

> **Corollaire 4.2 (Pythagore comme cas particulier).** Si $\widehat{A}=\pi/2$, alors $\cos\widehat{A}=0$ et $a^2=b^2+c^2$.

> **Corollaire 4.3 $(\star)$ (Loi des sinus).** Dans un triangle $ABC$ d'aire $\mathscr{A}$,
> $$\frac{a}{\sin\widehat{A}}=\frac{b}{\sin\widehat{B}}=\frac{c}{\sin\widehat{C}}=2R,$$
> où $R$ est le rayon du cercle circonscrit.

**Démonstration $(\star)$ — esquisse.** L'aire vaut $\mathscr{A}=\frac{1}{2}bc\sin\widehat{A}=\frac{1}{2}ca\sin\widehat{B}=\frac{1}{2}ab\sin\widehat{C}$. En divisant chaque égalité par $\frac{abc}{2}$, on obtient les trois rapports égaux. Le facteur $2R$ s'établit en complétant par la propriété de l'angle inscrit. ∎

---

## 5. La transformation $\vec{MA}\cdot\vec{MB}$

### 5.1. Le théorème central

> **Théorème 5.1 (Réduction de $\vec{MA}\cdot\vec{MB}$).** Soit $I$ le milieu de $[AB]$. Pour tout point $M$ du plan,
> $$\vec{MA}\cdot\vec{MB} = MI^2 - \tfrac{1}{4}AB^2.$$

**Démonstration.** On décompose $\vec{MA}=\vec{MI}+\vec{IA}$ et $\vec{MB}=\vec{MI}+\vec{IB}$. Or $I$ étant le milieu, $\vec{IB}=-\vec{IA}$. Donc :

$$\vec{MA}\cdot\vec{MB} = (\vec{MI}+\vec{IA})\cdot(\vec{MI}-\vec{IA})$$

$$= \|\vec{MI}\|^2 - \|\vec{IA}\|^2 \quad\text{(identité }a^2-b^2\text{)}$$

$$= MI^2 - \left(\tfrac{AB}{2}\right)^2 = MI^2 - \tfrac{AB^2}{4}. \quad\blacksquare$$

### 5.2. Application : caractérisation du cercle de diamètre $[AB]$

> **Théorème 5.2 (Cercle vu sous un angle droit).** Soient $A,B$ deux points distincts. L'ensemble
> $$\mathscr{C} = \{M\in\mathscr{P}\mid \vec{MA}\cdot\vec{MB}=0\}$$
> est exactement le cercle de diamètre $[AB]$.

**Démonstration.** Par le théorème 5.1, $\vec{MA}\cdot\vec{MB}=0\iff MI^2=\frac{AB^2}{4}\iff MI=\frac{AB}{2}$, où $I$ est le milieu de $[AB]$. C'est exactement la définition du cercle de centre $I$ et de rayon $\frac{AB}{2}$. ∎

> 💡 **Théorème de Thalès (le bon).** Ce résultat est traditionnellement attribué à Thalès de Milet (VIᵉ s. av. J.-C.) : « Tout angle inscrit dans un demi-cercle est droit. » La preuve par produit scalaire ci-dessus rend ce théorème presque tautologique.

### 5.3. Plus généralement : lignes de niveau

> **Proposition 5.3 (Lignes de niveau de $\vec{MA}\cdot\vec{MB}$).** Pour $k\in\mathbb{R}$, l'ensemble $\{M\mid \vec{MA}\cdot\vec{MB}=k\}$ est :
> - le cercle de centre $I$ et de rayon $\sqrt{k+\frac{AB^2}{4}}$, si $k>-\frac{AB^2}{4}$ ;
> - le singleton $\{I\}$, si $k=-\frac{AB^2}{4}$ ;
> - l'ensemble vide, si $k<-\frac{AB^2}{4}$.

**Démonstration.** $\vec{MA}\cdot\vec{MB}=k\iff MI^2=k+\frac{AB^2}{4}$. Discussion sur le signe. ∎

---

## 6. Géométrie repérée

> *Dans toute cette section, le plan est muni d'un repère orthonormé direct $(O;\vec{i},\vec{j})$.*

### 6.1. Vecteurs normaux et équations de droite

> **Définition 6.1 (Vecteur normal).** Un vecteur $\vec{n}\neq\vec{0}$ est *normal* à une droite $D$ si $\vec{n}$ est orthogonal à un (donc à tout) vecteur directeur de $D$.

> **Théorème 6.2 (Équation cartésienne par vecteur normal).** Soient $A(x_A,y_A)$ et $\vec{n}=(a,b)\neq\vec{0}$. La droite $D$ passant par $A$ et de vecteur normal $\vec{n}$ a pour équation cartésienne :
> $$a(x-x_A)+b(y-y_A)=0,\quad\text{c'est-à-dire}\quad ax+by+c=0,\ \text{avec }c=-(ax_A+by_A).$$
> Réciproquement, toute droite $ax+by+c=0$ (avec $(a,b)\neq(0,0)$) admet $\vec{n}=(a,b)$ comme vecteur normal et $\vec{u}=(-b,a)$ comme vecteur directeur.

**Démonstration.** $M(x,y)\in D\iff \vec{AM}\perp\vec{n}\iff \vec{AM}\cdot\vec{n}=0\iff a(x-x_A)+b(y-y_A)=0$.

Pour la réciproque : posons $\vec{u}=(-b,a)$. Alors $\vec{u}\cdot\vec{n}=(-b)\cdot a + a\cdot b=0$. Donc $\vec{u}\perp\vec{n}$, et comme $\vec{u}\neq\vec{0}$, c'est un vecteur directeur de $D$. ∎

> 🛠️ **Méthode — Lecture instantanée d'une équation $ax+by+c=0$ :**
> - Vecteur normal : $\vec{n}=(a,b)$.
> - Vecteur directeur : $\vec{u}=(-b,a)$.
> - Pente (si $b\neq 0$) : $-a/b$.

### 6.2. Distance d'un point à une droite

> **Théorème 6.3 $(\star)$ (Distance point-droite).** La distance d'un point $M_0(x_0,y_0)$ à la droite $D:ax+by+c=0$ est :
> $$d(M_0,D)=\frac{|ax_0+by_0+c|}{\sqrt{a^2+b^2}}.$$

**Démonstration $(\star)$.** Soit $H$ le projeté orthogonal de $M_0$ sur $D$. Alors $\vec{HM_0}=t\vec{n}$ pour un certain $t\in\mathbb{R}$. Or $H\in D$, donc $aH_x+bH_y+c=0$, soit $a(x_0-ta)+b(y_0-tb)+c=0$, d'où $t=\frac{ax_0+by_0+c}{a^2+b^2}$. Donc

$$d(M_0,D)=\|\vec{HM_0}\|=|t|\cdot\|\vec{n}\|=\frac{|ax_0+by_0+c|}{a^2+b^2}\cdot\sqrt{a^2+b^2}=\frac{|ax_0+by_0+c|}{\sqrt{a^2+b^2}}. \quad\blacksquare$$

### 6.3. Projeté orthogonal sur une droite

> 🛠️ **Méthode — Calcul d'un projeté orthogonal.** Pour projeter $M_0$ sur $D:ax+by+c=0$ :
> 1. Vecteur normal $\vec{n}=(a,b)$.
> 2. Le projeté $H$ vérifie $H=M_0+t\vec{n}$ avec $t\in\mathbb{R}$ tel que $H\in D$.
> 3. Substituer dans l'équation : $a(x_0+ta)+b(y_0+tb)+c=0$, donc $t=-\frac{ax_0+by_0+c}{a^2+b^2}$.
> 4. Calculer $H=(x_0+ta,y_0+tb)$.
>
> **Méthode alternative :** paramétrer $D$ par $A+s\vec{u}$ et chercher $s$ tel que $\vec{AH}\cdot\vec{u}=\vec{AM_0}\cdot\vec{u}$.

### 6.4. Équation de cercle

> **Théorème 6.4 (Équation cartésienne d'un cercle).** Le cercle de centre $\Omega(\alpha,\beta)$ et de rayon $r>0$ a pour équation :
> $$(x-\alpha)^2+(y-\beta)^2=r^2.$$
> Réciproquement, $x^2+y^2+ux+vy+w=0$ représente :
> - un cercle de centre $\Omega(-u/2,-v/2)$ et de rayon $r=\sqrt{\frac{u^2+v^2}{4}-w}$, si $\frac{u^2+v^2}{4}-w>0$ ;
> - un point isolé, si $\frac{u^2+v^2}{4}-w=0$ ;
> - l'ensemble vide, sinon.

> 🛠️ **Méthode — Mise sous forme canonique.** Devant $x^2+y^2+ux+vy+w=0$ :
> $$x^2+ux=\Bigl(x+\tfrac{u}{2}\Bigr)^2-\tfrac{u^2}{4},\qquad y^2+vy=\Bigl(y+\tfrac{v}{2}\Bigr)^2-\tfrac{v^2}{4}.$$
> On obtient $\bigl(x+\tfrac{u}{2}\bigr)^2+\bigl(y+\tfrac{v}{2}\bigr)^2=\tfrac{u^2+v^2}{4}-w$.

**Exemple type.** $x^2+y^2-4x+6y-12=0$. On regroupe : $(x-2)^2-4+(y+3)^2-9-12=0$, soit $(x-2)^2+(y+3)^2=25$. Centre $\Omega(2,-3)$, rayon $5$.

### 6.5. Parabole et fonction du second degré

> **Théorème 6.5 (Sommet et axe de symétrie).** La courbe représentative de $f(x)=ax^2+bx+c$ ($a\neq 0$) est une parabole. Son sommet est
> $$S\Bigl(-\tfrac{b}{2a},\, c-\tfrac{b^2}{4a}\Bigr),$$
> et son axe de symétrie est la droite verticale $x=-\frac{b}{2a}$.

**Démonstration.** Forme canonique : $f(x)=a\bigl(x+\frac{b}{2a}\bigr)^2+c-\frac{b^2}{4a}$. Le minimum (si $a>0$) ou maximum (si $a<0$) est atteint en $x=-\frac{b}{2a}$. ∎

> 💡 **Cas particulier.** L'ensemble des points équidistants de la droite $y=-1/4$ et du point $F(0,1/4)$ est la parabole $y=x^2$. Plus généralement, toute parabole se définit comme « ensemble des points équidistants d'une droite (directrice) et d'un point (foyer) ». C'est le pont avec la définition géométrique des coniques.

---

## 7. Méthodes consolidées

> 🛠️ **Comment choisir la formule du produit scalaire ?**
> 1. **Repère orthonormé visible** → (F3) coordonnées.
> 2. **Angle ou cosinus connu** → (F1).
> 3. **Configuration avec une perpendicularité dans la figure** → (F2) projection.
> 4. **Trois normes connues** → (F4).
> 5. **Vecteurs liés à un milieu** → identité $\vec{MA}\cdot\vec{MB}=MI^2-\frac{AB^2}{4}$.

> 🛠️ **Démontrer une orthogonalité.**
> 1. Calculer $\vec{u}\cdot\vec{v}$ par la formule la plus adaptée.
> 2. Montrer que c'est $0$.
> 3. Conclure : $\vec{u}\perp\vec{v}$.

> 🛠️ **Déterminer un lieu géométrique.** Quand on cherche $\{M\mid \text{condition}(M)\}$ :
> 1. Traduire la condition par une équation vectorielle ou algébrique.
> 2. Reconnaître la nature : droite ($\vec{n}\cdot\vec{AM}=0$), cercle ($\vec{MA}\cdot\vec{MB}=k$ ou $MI=r$), médiatrice ($MA=MB$), etc.
> 3. Donner une équation cartésienne.

> 🛠️ **Calculer un angle.**
> $$\cos\widehat{\vec{u},\vec{v}}=\frac{\vec{u}\cdot\vec{v}}{\|\vec{u}\|\cdot\|\vec{v}\|} = \frac{xx'+yy'}{\sqrt{x^2+y^2}\cdot\sqrt{x'^2+y'^2}}.$$

---

## 8. Pièges et erreurs récurrentes

> ⚠️ **(F3) suppose une BON.** $\vec{u}\cdot\vec{v}=xx'+yy'$ **n'est valable qu'en base orthonormée**. En base quelconque, l'expression fait intervenir une matrice non triviale (« matrice de Gram », MPSI). *Si le repère n'est pas précisé orthonormé, ne l'utilise pas.*

> ⚠️ **Confusion produit scalaire / produit vectoriel.** $\vec{u}\cdot\vec{v}\in\mathbb{R}$ (scalaire). Le *produit vectoriel* $\vec{u}\wedge\vec{v}$ (en dimension 3, hors-programme) est un *vecteur*. Ne pas écrire $\vec{u}\cdot\vec{v}=\vec{0}$ : c'est faux par type. Écrire $\vec{u}\cdot\vec{v}=0$.

> ⚠️ **Bilinéarité abusive.** $\vec{u}\cdot(\vec{v}\cdot\vec{w})$ **n'a aucun sens** : $\vec{v}\cdot\vec{w}$ est un réel, donc $\vec{u}\cdot(\vec{v}\cdot\vec{w})$ serait « produit scalaire d'un vecteur et d'un réel », non défini. (En revanche $(\vec{v}\cdot\vec{w})\vec{u}$ est défini : c'est un vecteur.)

> ⚠️ **Signe et orientation.** $\vec{u}\cdot\vec{v}<0$ signifie $\cos\theta<0$, donc $\theta\in\,]\pi/2,\pi]$ : angle obtus.

> ⚠️ **Norme vs distance.** $\|\vec{AB}\|=AB$ : la norme du vecteur égale la distance entre les points. Ne pas écrire $\|AB\|$ (sans flèche) : c'est ambigu.

> ⚠️ **Perpendicularité de droites vs orthogonalité de vecteurs.** Deux droites sont *perpendiculaires* ssi leurs vecteurs directeurs sont *orthogonaux et non nuls*. « Le vecteur nul est orthogonal à tout » mais le vecteur nul ne dirige aucune droite.

> ⚠️ **$ax+by+c=0$ vs $y=mx+p$.** Toute droite admet une équation $ax+by+c=0$, mais pas toujours $y=mx+p$ (les verticales $x=k$ n'ont pas de pente). Préfère la forme cartésienne générale.

---

## 9. Théorèmes à savoir réciter (mode colle)

À l'oral, tu dois pouvoir énoncer en moins de 30 secondes, sans aide :

1. Définition du produit scalaire (4 formes).
2. Bilinéarité, symétrie, positivité.
3. Caractérisation $\vec{u}\perp\vec{v}\iff \vec{u}\cdot\vec{v}=0$.
4. Pythagore vectoriel.
5. Al-Kashi.
6. Formule $\vec{MA}\cdot\vec{MB}=MI^2-\frac{AB^2}{4}$.
7. Caractérisation du cercle de diamètre $[AB]$.
8. Vecteur normal, équation cartésienne d'une droite.
9. Forme canonique d'un cercle.
10. Sommet d'une parabole.

Et tu dois pouvoir **démontrer** :
- Al-Kashi (au programme).
- Caractérisation du cercle de diamètre $[AB]$ (au programme).
- Pythagore vectoriel.
- Identité du parallélogramme.
- Critère de colinéarité par déterminant.
- Réduction $\vec{MA}\cdot\vec{MB}$ avec le milieu.

---

## 10. Ouvertures vers la MPSI

> 🚀 **Espace euclidien général.** En MPSI, on définit un *espace euclidien* comme un $\mathbb{R}$-espace vectoriel de dimension finie muni d'un produit scalaire, c'est-à-dire d'une forme bilinéaire symétrique définie positive (B1)–(B6). Tout ce que tu apprends ici se transpose tel quel à $\mathbb{R}^n$, à l'espace des polynômes muni de $\langle P,Q\rangle=\int_0^1 PQ$, etc.

> 🚀 **Inégalité de Cauchy–Schwarz.** Pour tous vecteurs $\vec{u},\vec{v}$ :
> $$|\vec{u}\cdot\vec{v}|\leq \|\vec{u}\|\cdot\|\vec{v}\|,$$
> avec égalité ssi $\vec{u},\vec{v}$ colinéaires. C'est la formule (F1) déguisée (puisque $|\cos\theta|\leq 1$). Mais en MPSI, on la démontre sans recourir à un angle, en étudiant le polynôme $\lambda\mapsto\|\vec{u}+\lambda\vec{v}\|^2\geq 0$ et son discriminant.

> 🚀 **Inégalité triangulaire.** $\|\vec{u}+\vec{v}\|\leq \|\vec{u}\|+\|\vec{v}\|$.
>
> *Démonstration :* $\|\vec{u}+\vec{v}\|^2=\|\vec{u}\|^2+2\vec{u}\cdot\vec{v}+\|\vec{v}\|^2\leq \|\vec{u}\|^2+2\|\vec{u}\|\|\vec{v}\|+\|\vec{v}\|^2=(\|\vec{u}\|+\|\vec{v}\|)^2$ (par Cauchy–Schwarz), puis on prend la racine.

> 🚀 **Orthogonal d'un sous-espace.** En MPSI, on définit
> $$F^\perp=\{\vec{v}\mid \forall\vec{u}\in F,\ \vec{u}\cdot\vec{v}=0\},$$
> et on montre que tout vecteur se décompose de façon unique en $\vec{x}=\vec{x}_F+\vec{x}_{F^\perp}$.

---

## 11. Synthèse

**Produit scalaire** : opération $V\times V\to\mathbb{R}$, bilinéaire, symétrique, $\vec{u}\cdot\vec{u}=\|\vec{u}\|^2\geq 0$.

**Quatre calculs équivalents :**

$$\vec{u}\cdot\vec{v}=\|\vec{u}\|\|\vec{v}\|\cos\theta = \pm\|\vec{u}\|\|\vec{v}'\| = xx'+yy' = \tfrac{1}{2}(\|\vec{u}+\vec{v}\|^2-\|\vec{u}\|^2-\|\vec{v}\|^2).$$

**Identités clés :**

$$\|\vec{u}\pm\vec{v}\|^2=\|\vec{u}\|^2\pm 2\vec{u}\cdot\vec{v}+\|\vec{v}\|^2$$

$$\vec{MA}\cdot\vec{MB}=MI^2-\tfrac{AB^2}{4}$$

**Orthogonalité** : $\vec{u}\perp\vec{v}\iff\vec{u}\cdot\vec{v}=0$.

**Pythagore** : $\vec{u}\perp\vec{v}\iff\|\vec{u}+\vec{v}\|^2=\|\vec{u}\|^2+\|\vec{v}\|^2$.

**Al-Kashi** : $a^2=b^2+c^2-2bc\cos\widehat{A}$.

**Géométrie repérée (BON) :**
- Droite $ax+by+c=0$ : normal $(a,b)$, directeur $(-b,a)$.
- Cercle $(x-\alpha)^2+(y-\beta)^2=r^2$.
- Distance point-droite : $\frac{|ax_0+by_0+c|}{\sqrt{a^2+b^2}}$.
- Parabole $y=ax^2+bx+c$ : sommet $\bigl(-\frac{b}{2a},\, c-\frac{b^2}{4a}\bigr)$, axe $x=-\frac{b}{2a}$.

---

*Cours rédigé pour révisions actives : reconstruis chaque démonstration sans regarder, puis vérifie.*
