# Géométrie vectorielle et produit scalaire

Cours approfondi de Première spécialité mathématiques, niveau cible **MPSI / CPGE**.

## Contenu

- [`cours.md`](cours.md) — cours complet en Markdown (rendu LaTeX natif GitHub)
- [`cours.pdf`](cours.pdf) — version PDF compilée
- [`cours.tex`](cours.tex) — source LaTeX

## Structure

1. Vecteurs : du concret à la structure (espace vectoriel)
2. Produit scalaire : 4 définitions équivalentes + démonstration
3. Orthogonalité, Pythagore vectoriel
4. Formule d'Al-Kashi
5. Transformation $\vec{MA}\cdot\vec{MB}$
6. Géométrie repérée (droites, cercles, paraboles)
7. Méthodes consolidées
8. Pièges classiques
9. Ouvertures MPSI (Cauchy-Schwarz, orthogonal d'un sev)

## Compilation

```bash
pdflatex cours.tex
pdflatex cours.tex   # 2 passes pour la table des matières
```

## Lecture sur GitHub

Le fichier `cours.md` utilise la syntaxe MathJax que GitHub rend nativement. Ouvre-le directement dans l'interface GitHub.
