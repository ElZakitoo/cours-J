// Utilitaires partagés
function $(id) { return document.getElementById(id); }

function gridSVG(w, h) {
  let g = '';
  for (let i = -w; i <= w; i++) {
    g += `<line x1="${i}" y1="${-h}" x2="${i}" y2="${h}" stroke="var(--border)" stroke-width="0.02" stroke-opacity="0.5"/>`;
  }
  for (let j = -h; j <= h; j++) {
    g += `<line x1="${-w}" y1="${j}" x2="${w}" y2="${j}" stroke="var(--border)" stroke-width="0.02" stroke-opacity="0.5"/>`;
  }
  return g;
}

function svgCoords(svg, evt) {
  const pt = svg.createSVGPoint();
  pt.x = (evt.clientX !== undefined) ? evt.clientX : evt.touches[0].clientX;
  pt.y = (evt.clientY !== undefined) ? evt.clientY : evt.touches[0].clientY;
  const ctm = svg.getScreenCTM().inverse();
  const p = pt.matrixTransform(ctm);
  return { x: p.x, y: -p.y }; // y inversé : maths vers le haut
}

function setupDragging(svg, getPoints, setPoint, onChange) {
  let dragging = null;
  function start(e) {
    const target = e.target;
    const pt = target.getAttribute('data-pt');
    if (pt) {
      dragging = pt;
      e.preventDefault();
    }
  }
  function move(e) {
    if (!dragging) return;
    e.preventDefault();
    const c = svgCoords(svg, e);
    setPoint(dragging, c);
    onChange();
  }
  function end() { dragging = null; }
  svg.addEventListener('mousedown', start);
  window.addEventListener('mousemove', move);
  window.addEventListener('mouseup', end);
  svg.addEventListener('touchstart', start, { passive: false });
  window.addEventListener('touchmove', move, { passive: false });
  window.addEventListener('touchend', end);
}

function dist(P, Q) { return Math.hypot(P.x - Q.x, P.y - Q.y); }
function dot(U, V)  { return U.x * V.x + U.y * V.y; }
function norm(U)    { return Math.hypot(U.x, U.y); }
function sub(P, Q)  { return { x: P.x - Q.x, y: P.y - Q.y }; }
function add(P, Q)  { return { x: P.x + Q.x, y: P.y + Q.y }; }
function scl(k, U)  { return { x: k * U.x, y: k * U.y }; }
function mid(P, Q)  { return { x: (P.x + Q.x) / 2, y: (P.y + Q.y) / 2 }; }
