// ============================================================
// Widgets interactifs — vecteurs et produit scalaire
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
  // Grilles partagées
  document.querySelectorAll('[id$="-grid"]').forEach(g => {
    g.innerHTML = gridSVG(9, 6);
  });
  initW1(); initW2(); initW3(); initW4(); initW5(); initW6();
  initW7(); initW8(); initW9(); initW10(); initW11(); initW12();
});

// ============================================================
// W1 — 4 formules du produit scalaire
// ============================================================
function initW1() {
  const ids = ['ux','uy','vx','vy'];
  function read() {
    return ids.reduce((o, id) => {
      const v = parseFloat($('w1-'+id).value);
      $('w1-'+id+'-o').textContent = v.toFixed(1);
      o[id] = v;
      return o;
    }, {});
  }
  function update() {
    const {ux,uy,vx,vy} = read();
    const u = {x:ux, y:uy}, v = {x:vx, y:vy};
    const nu = norm(u), nv = norm(v);
    const ps = dot(u, v);
    let theta = 0;
    if (nu > 1e-6 && nv > 1e-6) theta = Math.acos(Math.max(-1, Math.min(1, ps/(nu*nv))));
    
    const f1 = nu * nv * Math.cos(theta);
    let projX = 0, projY = 0, projLen = 0;
    if (nu > 1e-6) {
      const t = ps / (nu*nu);
      projX = t * ux; projY = t * uy;
      projLen = Math.hypot(projX, projY) * Math.sign(t || 1);
    }
    const f2 = nu * projLen;
    const f3 = ux*vx + uy*vy;
    const sx = ux+vx, sy = uy+vy;
    const f4 = 0.5 * ((sx*sx+sy*sy) - (ux*ux+uy*uy) - (vx*vx+vy*vy));
    
    $('w1-f1').textContent = f1.toFixed(2);
    $('w1-f2').textContent = f2.toFixed(2);
    $('w1-f3').textContent = f3.toFixed(2);
    $('w1-f4').textContent = f4.toFixed(2);
    $('w1-ang').textContent = (theta*180/Math.PI).toFixed(1);
    $('w1-nu').textContent = nu.toFixed(2);
    $('w1-nv').textContent = nv.toFixed(2);
    
    let s = '';
    if (nu > 1e-6) {
      s += `<line x1="${vx}" y1="${-vy}" x2="${projX}" y2="${-projY}" stroke="var(--text-soft)" stroke-width="0.04" stroke-dasharray="0.2 0.15"/>`;
      s += `<line x1="0" y1="0" x2="${projX}" y2="${-projY}" stroke="#0F6E56" stroke-width="0.12" marker-end="url(#w1-ap)"/>`;
      s += `<text x="${projX/2 + 0.2}" y="${-projY/2 - 0.3}" font-size="0.5" fill="#0F6E56">v'</text>`;
    }
    s += `<line x1="0" y1="0" x2="${ux}" y2="${-uy}" stroke="#185FA5" stroke-width="0.14" marker-end="url(#w1-au)"/>`;
    s += `<text x="${ux+0.3}" y="${-uy+0.2}" font-size="0.6" fill="#185FA5" font-weight="500">u</text>`;
    s += `<line x1="0" y1="0" x2="${vx}" y2="${-vy}" stroke="#993C1D" stroke-width="0.14" marker-end="url(#w1-av)"/>`;
    s += `<text x="${vx+0.3}" y="${-vy+0.2}" font-size="0.6" fill="#993C1D" font-weight="500">v</text>`;
    if (nu > 0.5 && nv > 0.5) {
      const r = 1;
      const au = Math.atan2(-uy, ux), av = Math.atan2(-vy, vx);
      let large = Math.abs(av - au) > Math.PI ? 1 : 0;
      let sweep = (av > au) ? 1 : 0;
      if (Math.abs(av - au) > Math.PI) sweep = 1 - sweep;
      s += `<path d="M ${r*Math.cos(au)} ${r*Math.sin(au)} A ${r} ${r} 0 ${large} ${sweep} ${r*Math.cos(av)} ${r*Math.sin(av)}" stroke="var(--text-muted)" stroke-width="0.04" fill="none"/>`;
      s += `<text x="${1.4*Math.cos((au+av)/2)}" y="${1.4*Math.sin((au+av)/2)+0.15}" font-size="0.45" fill="var(--text-muted)" text-anchor="middle">θ</text>`;
    }
    $('w1-dyn').innerHTML = s;
  }
  ids.forEach(id => $('w1-'+id).addEventListener('input', update));
  update();
}

// ============================================================
// W2 — Bilinéarité
// ============================================================
function initW2() {
  const ids = ['ux','uy','vx','vy','wx','wy'];
  function read() {
    return ids.reduce((o, id) => {
      const v = parseFloat($('w2-'+id).value);
      $('w2-'+id+'-o').textContent = v.toFixed(1);
      o[id] = v;
      return o;
    }, {});
  }
  function update() {
    const {ux,uy,vx,vy,wx,wy} = read();
    const u = {x:ux,y:uy}, v = {x:vx,y:vy}, w = {x:wx,y:wy};
    const vw = add(v, w);
    const lhs = dot(u, vw);
    const uv = dot(u, v), uw = dot(u, w);
    const rhs = uv + uw;
    
    $('w2-lhs').textContent = lhs.toFixed(3);
    $('w2-rhs').textContent = rhs.toFixed(3);
    $('w2-uv').textContent = uv.toFixed(2);
    $('w2-uw').textContent = uw.toFixed(2);
    
    let s = '';
    s += `<line x1="0" y1="0" x2="${ux}" y2="${-uy}" stroke="#185FA5" stroke-width="0.14"/>`;
    s += `<text x="${ux+0.3}" y="${-uy+0.2}" font-size="0.55" fill="#185FA5" font-weight="500">u</text>`;
    s += `<line x1="0" y1="0" x2="${vx}" y2="${-vy}" stroke="#993C1D" stroke-width="0.1"/>`;
    s += `<text x="${vx+0.3}" y="${-vy+0.2}" font-size="0.5" fill="#993C1D">v</text>`;
    s += `<line x1="0" y1="0" x2="${wx}" y2="${-wy}" stroke="#0F6E56" stroke-width="0.1"/>`;
    s += `<text x="${wx+0.3}" y="${-wy+0.2}" font-size="0.5" fill="#0F6E56">w</text>`;
    s += `<line x1="0" y1="0" x2="${vw.x}" y2="${-vw.y}" stroke="#534AB7" stroke-width="0.12"/>`;
    s += `<text x="${vw.x+0.3}" y="${-vw.y+0.2}" font-size="0.55" fill="#534AB7" font-weight="500">v+w</text>`;
    s += `<line x1="${vx}" y1="${-vy}" x2="${vw.x}" y2="${-vw.y}" stroke="#0F6E56" stroke-width="0.06" stroke-dasharray="0.15 0.1"/>`;
    $('w2-dyn').innerHTML = s;
  }
  ids.forEach(id => $('w2-'+id).addEventListener('input', update));
  update();
}

// ============================================================
// W3 — Pythagore vectoriel
// ============================================================
function initW3() {
  const ids = ['ux','uy','vx','vy'];
  function read() {
    return ids.reduce((o, id) => {
      const v = parseFloat($('w3-'+id).value);
      $('w3-'+id+'-o').textContent = v.toFixed(1);
      o[id] = v;
      return o;
    }, {});
  }
  function update() {
    const {ux,uy,vx,vy} = read();
    const u = {x:ux,y:uy}, v = {x:vx,y:vy};
    const sum = add(u, v);
    const lhs = norm(sum)**2;
    const rhs = norm(u)**2 + norm(v)**2;
    const gap = lhs - rhs;
    
    $('w3-lhs').textContent = lhs.toFixed(2);
    $('w3-rhs').textContent = rhs.toFixed(2);
    $('w3-status').textContent = gap.toFixed(2);
    const card = $('w3-status-card');
    if (Math.abs(gap) < 0.05) {
      card.style.background = 'var(--info-soft)';
      card.style.color = 'var(--info)';
      $('w3-status').textContent = '≈ 0  ⟹  u ⊥ v ✓';
    } else {
      card.style.background = '';
      card.style.color = '';
    }
    
    // Triangle u, v, u+v
    let s = '';
    s += `<polygon points="0,0 ${ux},${-uy} ${sum.x},${-sum.y}" fill="rgba(83,74,183,0.05)" stroke="none"/>`;
    s += `<line x1="0" y1="0" x2="${ux}" y2="${-uy}" stroke="#185FA5" stroke-width="0.12"/>`;
    s += `<text x="${ux/2+0.3}" y="${-uy/2-0.2}" font-size="0.5" fill="#185FA5" font-weight="500">u</text>`;
    s += `<line x1="${ux}" y1="${-uy}" x2="${sum.x}" y2="${-sum.y}" stroke="#993C1D" stroke-width="0.12"/>`;
    s += `<text x="${(ux+sum.x)/2+0.3}" y="${-(uy+sum.y)/2-0.2}" font-size="0.5" fill="#993C1D" font-weight="500">v</text>`;
    s += `<line x1="0" y1="0" x2="${sum.x}" y2="${-sum.y}" stroke="#0F6E56" stroke-width="0.14"/>`;
    s += `<text x="${sum.x/2+0.3}" y="${-sum.y/2+0.4}" font-size="0.55" fill="#0F6E56" font-weight="500">u+v</text>`;
    // angle droit en sommet u si u⊥v
    if (Math.abs(gap) < 0.1 && norm(u) > 0.5 && norm(v) > 0.5) {
      // petit carré indiquant l'angle droit au point u
      const sz = 0.3;
      const uHat = { x: ux/norm(u), y: uy/norm(u) };
      const vHat = { x: (sum.x-ux)/norm(v), y: (sum.y-uy)/norm(v) };
      const p1 = {x: ux - sz*uHat.x, y: uy - sz*uHat.y};
      const p2 = {x: ux - sz*uHat.x + sz*vHat.x, y: uy - sz*uHat.y + sz*vHat.y};
      const p3 = {x: ux + sz*vHat.x, y: uy + sz*vHat.y};
      s += `<polyline points="${p1.x},${-p1.y} ${p2.x},${-p2.y} ${p3.x},${-p3.y}" fill="none" stroke="var(--text-muted)" stroke-width="0.04"/>`;
    }
    $('w3-dyn').innerHTML = s;
  }
  ids.forEach(id => $('w3-'+id).addEventListener('input', update));
  update();
}

// ============================================================
// W4 — Identité du parallélogramme
// ============================================================
function initW4() {
  const ids = ['ux','uy','vx','vy'];
  function read() {
    return ids.reduce((o, id) => {
      const v = parseFloat($('w4-'+id).value);
      $('w4-'+id+'-o').textContent = v.toFixed(1);
      o[id] = v;
      return o;
    }, {});
  }
  function update() {
    const {ux,uy,vx,vy} = read();
    const u = {x:ux,y:uy}, v = {x:vx,y:vy};
    const sum = add(u, v), diff = sub(u, v);
    const lhs = norm(sum)**2 + norm(diff)**2;
    const rhs = 2*(norm(u)**2 + norm(v)**2);
    
    $('w4-lhs').textContent = lhs.toFixed(2);
    $('w4-rhs').textContent = rhs.toFixed(2);
    
    // parallélogramme : 0, u, u+v, v
    let s = '';
    s += `<polygon points="0,0 ${ux},${-uy} ${sum.x},${-sum.y} ${vx},${-vy}" fill="rgba(83,74,183,0.08)" stroke="#534AB7" stroke-width="0.07"/>`;
    // diagonales
    s += `<line x1="0" y1="0" x2="${sum.x}" y2="${-sum.y}" stroke="#0F6E56" stroke-width="0.12"/>`;
    s += `<text x="${sum.x/2+0.3}" y="${-sum.y/2}" font-size="0.5" fill="#0F6E56" font-weight="500">u+v</text>`;
    s += `<line x1="${ux}" y1="${-uy}" x2="${vx}" y2="${-vy}" stroke="#993C1D" stroke-width="0.12"/>`;
    s += `<text x="${(ux+vx)/2-0.5}" y="${-(uy+vy)/2}" font-size="0.5" fill="#993C1D" font-weight="500">u−v</text>`;
    // étiquettes côtés
    s += `<text x="${ux/2-0.2}" y="${-uy/2-0.2}" font-size="0.45" fill="#185FA5">u</text>`;
    s += `<text x="${vx/2-0.2}" y="${-vy/2-0.2}" font-size="0.45" fill="#185FA5">v</text>`;
    $('w4-dyn').innerHTML = s;
  }
  ids.forEach(id => $('w4-'+id).addEventListener('input', update));
  update();
}

// ============================================================
// W5 — Cauchy-Schwarz
// ============================================================
function initW5() {
  const ids = ['ux','uy','vx','vy'];
  function read() {
    return ids.reduce((o, id) => {
      const v = parseFloat($('w5-'+id).value);
      $('w5-'+id+'-o').textContent = v.toFixed(1);
      o[id] = v;
      return o;
    }, {});
  }
  function update() {
    const {ux,uy,vx,vy} = read();
    const u = {x:ux,y:uy}, v = {x:vx,y:vy};
    const lhs = Math.abs(dot(u, v));
    const rhs = norm(u)*norm(v);
    const gap = rhs - lhs;
    
    $('w5-lhs').textContent = lhs.toFixed(3);
    $('w5-rhs').textContent = rhs.toFixed(3);
    $('w5-gap').textContent = gap.toFixed(3) + (gap < 0.02 ? ' ✓ (égalité = colinéarité)' : '');
    
    let s = '';
    // droite portée par u (ligne pointillée prolongée)
    if (norm(u) > 0.3) {
      const k = 12 / norm(u);
      s += `<line x1="${-k*ux}" y1="${k*uy}" x2="${k*ux}" y2="${-k*uy}" stroke="#185FA5" stroke-width="0.04" stroke-dasharray="0.15 0.1" opacity="0.5"/>`;
    }
    s += `<line x1="0" y1="0" x2="${ux}" y2="${-uy}" stroke="#185FA5" stroke-width="0.14"/>`;
    s += `<text x="${ux+0.3}" y="${-uy+0.2}" font-size="0.55" fill="#185FA5" font-weight="500">u</text>`;
    s += `<line x1="0" y1="0" x2="${vx}" y2="${-vy}" stroke="#993C1D" stroke-width="0.14"/>`;
    s += `<text x="${vx+0.3}" y="${-vy+0.2}" font-size="0.55" fill="#993C1D" font-weight="500">v</text>`;
    $('w5-dyn').innerHTML = s;
  }
  ids.forEach(id => $('w5-'+id).addEventListener('input', update));
  update();
}

// ============================================================
// W6 — Décomposition orthogonale
// ============================================================
function initW6() {
  const ids = ['ux','uy','vx','vy'];
  function read() {
    return ids.reduce((o, id) => {
      const v = parseFloat($('w6-'+id).value);
      $('w6-'+id+'-o').textContent = v.toFixed(1);
      o[id] = v;
      return o;
    }, {});
  }
  function update() {
    const {ux,uy,vx,vy} = read();
    const u = {x:ux,y:uy}, v = {x:vx,y:vy};
    const nu2 = ux*ux + uy*uy;
    let par = {x:0,y:0};
    if (nu2 > 1e-6) par = scl(dot(u,v)/nu2, u);
    const orth = sub(v, par);
    
    $('w6-px').textContent = par.x.toFixed(2);
    $('w6-py').textContent = par.y.toFixed(2);
    $('w6-ox').textContent = orth.x.toFixed(2);
    $('w6-oy').textContent = orth.y.toFixed(2);
    $('w6-check').textContent = dot(par, orth).toFixed(3) + ' (≈0 ✓)';
    
    let s = '';
    // droite portée par u
    if (norm(u) > 0.3) {
      const k = 12 / norm(u);
      s += `<line x1="${-k*ux}" y1="${k*uy}" x2="${k*ux}" y2="${-k*uy}" stroke="#185FA5" stroke-width="0.04" stroke-dasharray="0.15 0.1" opacity="0.5"/>`;
    }
    // u
    s += `<line x1="0" y1="0" x2="${ux}" y2="${-uy}" stroke="#185FA5" stroke-width="0.12" marker-end="url(#w6-au)"/>`;
    s += `<text x="${ux+0.3}" y="${-uy+0.2}" font-size="0.5" fill="#185FA5" font-weight="500">u</text>`;
    // v
    s += `<line x1="0" y1="0" x2="${vx}" y2="${-vy}" stroke="#993C1D" stroke-width="0.14" marker-end="url(#w6-av)"/>`;
    s += `<text x="${vx+0.3}" y="${-vy+0.2}" font-size="0.55" fill="#993C1D" font-weight="500">v</text>`;
    // v_par (vert)
    s += `<line x1="0" y1="0" x2="${par.x}" y2="${-par.y}" stroke="#0F6E56" stroke-width="0.12" marker-end="url(#w6-ap)"/>`;
    s += `<text x="${par.x/2+0.2}" y="${-par.y/2-0.3}" font-size="0.45" fill="#0F6E56">v∥</text>`;
    // v_orth (violet) depuis l'extrémité de par
    s += `<line x1="${par.x}" y1="${-par.y}" x2="${vx}" y2="${-vy}" stroke="#534AB7" stroke-width="0.12" marker-end="url(#w6-ao)"/>`;
    s += `<text x="${(par.x+vx)/2+0.3}" y="${-(par.y+vy)/2}" font-size="0.45" fill="#534AB7">v⊥</text>`;
    // angle droit
    if (norm(par) > 0.3 && norm(orth) > 0.3) {
      const sz = 0.25;
      const pHat = { x: par.x/norm(par), y: par.y/norm(par) };
      const oHat = { x: orth.x/norm(orth), y: orth.y/norm(orth) };
      const p1 = {x: par.x - sz*pHat.x, y: par.y - sz*pHat.y};
      const p2 = {x: par.x - sz*pHat.x + sz*oHat.x, y: par.y - sz*pHat.y + sz*oHat.y};
      const p3 = {x: par.x + sz*oHat.x, y: par.y + sz*oHat.y};
      s += `<polyline points="${p1.x},${-p1.y} ${p2.x},${-p2.y} ${p3.x},${-p3.y}" fill="none" stroke="var(--text-muted)" stroke-width="0.04"/>`;
    }
    $('w6-dyn').innerHTML = s;
  }
  ids.forEach(id => $('w6-'+id).addEventListener('input', update));
  update();
}

// ============================================================
// W7 — Al-Kashi
// ============================================================
function initW7() {
  let A = {x:-3,y:-1.5}, B = {x:3,y:-1.5}, C = {x:0,y:3};
  
  function update() {
    const a = dist(B, C), b = dist(C, A), c = dist(A, B);
    function ang(P, Q, R) {
      const u = sub(Q, P), v = sub(R, P);
      const nu = norm(u), nv = norm(v);
      if (nu<1e-6 || nv<1e-6) return 0;
      return Math.acos(Math.max(-1, Math.min(1, dot(u,v)/(nu*nv))));
    }
    const angA = ang(A, B, C), angB = ang(B, A, C), angC = ang(C, A, B);
    
    $('w7-a').textContent = a.toFixed(2);
    $('w7-b').textContent = b.toFixed(2);
    $('w7-c').textContent = c.toFixed(2);
    $('w7-A').textContent = (angA*180/Math.PI).toFixed(1);
    $('w7-B').textContent = (angB*180/Math.PI).toFixed(1);
    $('w7-C').textContent = (angC*180/Math.PI).toFixed(1);
    $('w7-a2').textContent = (a*a).toFixed(2);
    $('w7-rhs').textContent = (b*b + c*c - 2*b*c*Math.cos(angA)).toFixed(2);
    
    let t = '';
    t += `<polygon points="${A.x},${-A.y} ${B.x},${-B.y} ${C.x},${-C.y}" fill="rgba(83,74,183,0.08)" stroke="#534AB7" stroke-width="0.07"/>`;
    const mAB = mid(A,B), mBC = mid(B,C), mCA = mid(C,A);
    t += `<text x="${mAB.x}" y="${-mAB.y-0.3}" font-size="0.5" fill="var(--text-muted)" text-anchor="middle">c</text>`;
    t += `<text x="${mBC.x+0.3}" y="${-mBC.y}" font-size="0.5" fill="var(--text-muted)">a</text>`;
    t += `<text x="${mCA.x-0.4}" y="${-mCA.y}" font-size="0.5" fill="var(--text-muted)">b</text>`;
    $('w7-tri').innerHTML = t;
    
    let p = '';
    [['A',A,'#185FA5'],['B',B,'#993C1D'],['C',C,'#0F6E56']].forEach(([n,P,col]) => {
      p += `<circle cx="${P.x}" cy="${-P.y}" r="0.2" fill="${col}" data-pt="${n}" style="cursor:grab"/>`;
      p += `<text x="${P.x+0.3}" y="${-P.y-0.3}" font-size="0.6" fill="${col}" font-weight="500">${n}</text>`;
    });
    $('w7-pts').innerHTML = p;
  }
  
  setupDragging($('w7-svg'), () => ({A,B,C}), (n, c) => {
    if (n==='A') A=c; else if (n==='B') B=c; else if (n==='C') C=c;
  }, update);
  update();
}

// ============================================================
// W8 — Médiatrice
// ============================================================
function initW8() {
  let A = {x:-3,y:0}, B = {x:3,y:0}, M = {x:1,y:2};
  
  function update() {
    const ma = dist(M,A), mb = dist(M,B);
    $('w8-ma').textContent = ma.toFixed(2);
    $('w8-mb').textContent = mb.toFixed(2);
    const diff = ma*ma - mb*mb;
    $('w8-diff').textContent = diff.toFixed(2);
    const card = $('w8-card');
    if (Math.abs(diff) < 0.05) {
      card.style.background = 'var(--info-soft)';
      card.style.color = 'var(--info)';
      $('w8-diff').textContent = '≈ 0  ⟹  M est sur la médiatrice ✓';
    } else {
      card.style.background = '';
      card.style.color = '';
    }
    
    // médiatrice : passe par milieu I, perpendiculaire à AB
    const I = mid(A, B);
    const AB = sub(B, A);
    const nAB = norm(AB);
    let m = '';
    if (nAB > 1e-6) {
      // direction perpendiculaire à AB : (-AB.y, AB.x) / nAB
      const perp = { x: -AB.y/nAB, y: AB.x/nAB };
      const k = 9;
      m += `<line x1="${I.x-k*perp.x}" y1="${-(I.y-k*perp.y)}" x2="${I.x+k*perp.x}" y2="${-(I.y+k*perp.y)}" stroke="#0F6E56" stroke-width="0.08" stroke-dasharray="0.25 0.15"/>`;
    }
    m += `<line x1="${A.x}" y1="${-A.y}" x2="${B.x}" y2="${-B.y}" stroke="var(--text-muted)" stroke-width="0.06"/>`;
    m += `<line x1="${M.x}" y1="${-M.y}" x2="${A.x}" y2="${-A.y}" stroke="#185FA5" stroke-width="0.05" stroke-dasharray="0.2 0.1"/>`;
    m += `<line x1="${M.x}" y1="${-M.y}" x2="${B.x}" y2="${-B.y}" stroke="#993C1D" stroke-width="0.05" stroke-dasharray="0.2 0.1"/>`;
    $('w8-med').innerHTML = m;
    
    let p = '';
    [['A',A,'#185FA5'],['B',B,'#993C1D'],['M',M,'#534AB7']].forEach(([n,P,col]) => {
      p += `<circle cx="${P.x}" cy="${-P.y}" r="0.2" fill="${col}" data-pt="${n}" style="cursor:grab"/>`;
      p += `<text x="${P.x+0.3}" y="${-P.y-0.3}" font-size="0.6" fill="${col}" font-weight="500">${n}</text>`;
    });
    p += `<circle cx="${I.x}" cy="${-I.y}" r="0.1" fill="var(--text-muted)"/>`;
    p += `<text x="${I.x+0.2}" y="${-I.y+0.5}" font-size="0.4" fill="var(--text-muted)">I</text>`;
    $('w8-pts').innerHTML = p;
  }
  
  setupDragging($('w8-svg'), () => ({A,B,M}), (n,c) => {
    if (n==='A') A=c; else if (n==='B') B=c; else if (n==='M') M=c;
  }, update);
  update();
}

// ============================================================
// W9 — MA·MB et cercle
// ============================================================
function initW9() {
  let A = {x:-3,y:0}, B = {x:3,y:0}, M = {x:0,y:2.5};
  
  function update() {
    const k = parseFloat($('w9-k').value);
    $('w9-k-o').textContent = k.toFixed(1);
    $('w9-kshow').textContent = k.toFixed(1);
    
    const I = mid(A, B);
    const AB = dist(A, B);
    const AB2_4 = AB*AB/4;
    const MA = sub(A, M), MB = sub(B, M);
    const dotMaMb = dot(MA, MB);
    const MI = dist(M, I);
    const form = MI*MI - AB2_4;
    
    $('w9-dot').textContent = dotMaMb.toFixed(2);
    $('w9-form').textContent = form.toFixed(2);
    
    const r2 = k + AB2_4;
    let lh = '';
    let nature = '';
    if (r2 > 1e-6) {
      const r = Math.sqrt(r2);
      lh = `<circle cx="${I.x}" cy="${-I.y}" r="${r}" fill="none" stroke="#0F6E56" stroke-width="0.08" stroke-dasharray="0.25 0.15"/>`;
      nature = `cercle, r ≈ ${r.toFixed(2)}`;
    } else if (Math.abs(r2) < 1e-6) {
      lh = `<circle cx="${I.x}" cy="${-I.y}" r="0.15" fill="#0F6E56"/>`;
      nature = `point I`;
    } else {
      nature = `vide`;
    }
    $('w9-locus').innerHTML = lh;
    $('w9-nature').textContent = nature;
    
    let v = '';
    v += `<line x1="${M.x}" y1="${-M.y}" x2="${A.x}" y2="${-A.y}" stroke="var(--text-soft)" stroke-width="0.05" stroke-dasharray="0.2 0.1"/>`;
    v += `<line x1="${M.x}" y1="${-M.y}" x2="${B.x}" y2="${-B.y}" stroke="var(--text-soft)" stroke-width="0.05" stroke-dasharray="0.2 0.1"/>`;
    v += `<line x1="${M.x}" y1="${-M.y}" x2="${I.x}" y2="${-I.y}" stroke="#534AB7" stroke-width="0.06"/>`;
    $('w9-vects').innerHTML = v;
    
    let p = '';
    p += `<line x1="${A.x}" y1="${-A.y}" x2="${B.x}" y2="${-B.y}" stroke="var(--text-muted)" stroke-width="0.06"/>`;
    p += `<circle cx="${A.x}" cy="${-A.y}" r="0.18" fill="#185FA5" data-pt="A" style="cursor:grab"/>`;
    p += `<text x="${A.x-0.5}" y="${-A.y-0.4}" font-size="0.55" fill="#185FA5" font-weight="500">A</text>`;
    p += `<circle cx="${B.x}" cy="${-B.y}" r="0.18" fill="#185FA5" data-pt="B" style="cursor:grab"/>`;
    p += `<text x="${B.x+0.3}" y="${-B.y-0.4}" font-size="0.55" fill="#185FA5" font-weight="500">B</text>`;
    p += `<circle cx="${I.x}" cy="${-I.y}" r="0.12" fill="#534AB7"/>`;
    p += `<text x="${I.x+0.2}" y="${-I.y+0.5}" font-size="0.45" fill="#534AB7">I</text>`;
    p += `<circle cx="${M.x}" cy="${-M.y}" r="0.2" fill="#993C1D" data-pt="M" style="cursor:grab"/>`;
    p += `<text x="${M.x+0.3}" y="${-M.y+0.2}" font-size="0.6" fill="#993C1D" font-weight="500">M</text>`;
    $('w9-pts').innerHTML = p;
  }
  
  setupDragging($('w9-svg'), () => ({A,B,M}), (n,c) => {
    if (n==='A') A=c; else if (n==='B') B=c; else if (n==='M') M=c;
  }, update);
  $('w9-k').addEventListener('input', update);
  $('w9-reset').addEventListener('click', () => { $('w9-k').value = 0; update(); });
  update();
}

// ============================================================
// W10 — Droite, projeté, distance
// ============================================================
function initW10() {
  let M = {x:4,y:3};
  
  function update() {
    const a = parseFloat($('w10-a').value);
    const b = parseFloat($('w10-b').value);
    const c = parseFloat($('w10-c').value);
    $('w10-a-o').textContent = a.toFixed(1);
    $('w10-b-o').textContent = b.toFixed(1);
    $('w10-c-o').textContent = c.toFixed(1);
    
    const nrm2 = a*a + b*b;
    if (nrm2 < 1e-6) return;
    
    let P1, P2;
    if (Math.abs(b) > Math.abs(a)) {
      P1 = {x:-10, y: -(a*-10+c)/b};
      P2 = {x: 10, y: -(a* 10+c)/b};
    } else {
      P1 = {x: -(b*-7+c)/a, y:-7};
      P2 = {x: -(b* 7+c)/a, y: 7};
    }
    
    const t = -(a*M.x + b*M.y + c)/nrm2;
    const H = {x: M.x+t*a, y: M.y+t*b};
    const distance = Math.abs(a*M.x + b*M.y + c)/Math.sqrt(nrm2);
    
    $('w10-mx').textContent = M.x.toFixed(2);
    $('w10-my').textContent = M.y.toFixed(2);
    $('w10-hx').textContent = H.x.toFixed(2);
    $('w10-hy').textContent = H.y.toFixed(2);
    $('w10-dist').textContent = distance.toFixed(3);
    
    $('w10-line').innerHTML = `<line x1="${P1.x}" y1="${-P1.y}" x2="${P2.x}" y2="${-P2.y}" stroke="#534AB7" stroke-width="0.1"/>`;
    
    const nrm = Math.sqrt(nrm2);
    const nU = {x: a/nrm, y: b/nrm};
    const uU = {x: -b/nrm, y: a/nrm};
    let v = '';
    v += `<line x1="${H.x}" y1="${-H.y}" x2="${H.x+1.5*nU.x}" y2="${-(H.y+1.5*nU.y)}" stroke="#993C1D" stroke-width="0.1" marker-end="url(#w10-an)"/>`;
    v += `<text x="${H.x+1.7*nU.x}" y="${-(H.y+1.7*nU.y)+0.2}" font-size="0.5" fill="#993C1D">n</text>`;
    v += `<line x1="${H.x}" y1="${-H.y}" x2="${H.x+1.5*uU.x}" y2="${-(H.y+1.5*uU.y)}" stroke="#0F6E56" stroke-width="0.1" marker-end="url(#w10-ad)"/>`;
    v += `<text x="${H.x+1.7*uU.x}" y="${-(H.y+1.7*uU.y)+0.2}" font-size="0.5" fill="#0F6E56">u</text>`;
    v += `<line x1="${M.x}" y1="${-M.y}" x2="${H.x}" y2="${-H.y}" stroke="#185FA5" stroke-width="0.07" stroke-dasharray="0.2 0.12"/>`;
    const sq = 0.25;
    const sgn = Math.sign(t || 1);
    const c1 = {x:H.x+sq*uU.x, y:H.y+sq*uU.y};
    const c2 = {x:H.x+sq*uU.x+sq*sgn*nU.x, y:H.y+sq*uU.y+sq*sgn*nU.y};
    const c3 = {x:H.x+sq*sgn*nU.x, y:H.y+sq*sgn*nU.y};
    v += `<polyline points="${c1.x},${-c1.y} ${c2.x},${-c2.y} ${c3.x},${-c3.y}" fill="none" stroke="var(--text-muted)" stroke-width="0.04"/>`;
    $('w10-vects').innerHTML = v;
    
    let p = '';
    p += `<circle cx="${H.x}" cy="${-H.y}" r="0.14" fill="#534AB7"/>`;
    p += `<text x="${H.x+0.25}" y="${-H.y+0.55}" font-size="0.45" fill="#534AB7">H</text>`;
    p += `<circle cx="${M.x}" cy="${-M.y}" r="0.2" fill="#185FA5" data-pt="M" style="cursor:grab"/>`;
    p += `<text x="${M.x+0.3}" y="${-M.y+0.2}" font-size="0.6" fill="#185FA5" font-weight="500">M</text>`;
    $('w10-pts').innerHTML = p;
  }
  
  setupDragging($('w10-svg'), () => ({M}), (n,c) => { if (n==='M') M=c; }, update);
  ['a','b','c'].forEach(id => $('w10-'+id).addEventListener('input', update));
  update();
}

// ============================================================
// W11 — Cercle (forme canonique)
// ============================================================
function initW11() {
  function update() {
    const u = parseFloat($('w11-u').value);
    const v = parseFloat($('w11-v').value);
    const w = parseFloat($('w11-w').value);
    $('w11-u-o').textContent = u.toFixed(1);
    $('w11-v-o').textContent = v.toFixed(1);
    $('w11-w-o').textContent = w.toFixed(1);
    
    const cx = -u/2, cy = -v/2;
    const r2 = u*u/4 + v*v/4 - w;
    $('w11-cx').textContent = cx.toFixed(2);
    $('w11-cy').textContent = cy.toFixed(2);
    $('w11-r2').textContent = r2.toFixed(2);
    
    const sx = cx >= 0 ? `(x − ${cx.toFixed(2)})²` : `(x + ${(-cx).toFixed(2)})²`;
    const sy = cy >= 0 ? `(y − ${cy.toFixed(2)})²` : `(y + ${(-cy).toFixed(2)})²`;
    $('w11-canon').textContent = `${sx} + ${sy} = ${r2.toFixed(2)}`;
    
    let h = '';
    if (r2 > 1e-6) {
      const r = Math.sqrt(r2);
      h = `<circle cx="${cx}" cy="${-cy}" r="${r}" fill="rgba(83,74,183,0.1)" stroke="#534AB7" stroke-width="0.08"/>
           <circle cx="${cx}" cy="${-cy}" r="0.12" fill="#534AB7"/>
           <text x="${cx+0.3}" y="${-cy-0.3}" font-size="0.5" fill="#534AB7">Ω</text>`;
      $('w11-status').textContent = `Cercle de rayon r = ${r.toFixed(2)}`;
      $('w11-status').style.color = 'var(--success)';
    } else if (Math.abs(r2) < 1e-6) {
      h = `<circle cx="${cx}" cy="${-cy}" r="0.18" fill="#534AB7"/>`;
      $('w11-status').textContent = `Point isolé { Ω }`;
      $('w11-status').style.color = 'var(--warning)';
    } else {
      $('w11-status').textContent = `Ensemble vide (r² < 0)`;
      $('w11-status').style.color = 'var(--danger)';
    }
    $('w11-circle').innerHTML = h;
  }
  ['u','v','w'].forEach(id => $('w11-'+id).addEventListener('input', update));
  update();
}

// ============================================================
// W12 — Parabole
// ============================================================
function initW12() {
  function update() {
    const a = parseFloat($('w12-a').value);
    const b = parseFloat($('w12-b').value);
    const c = parseFloat($('w12-c').value);
    $('w12-a-o').textContent = a.toFixed(1);
    $('w12-b-o').textContent = b.toFixed(1);
    $('w12-c-o').textContent = c.toFixed(1);
    
    if (Math.abs(a) < 1e-6) {
      $('w12-canon').textContent = 'a = 0 : ce n\'est plus une parabole.';
      $('w12-parab').innerHTML = '';
      return;
    }
    
    const sx = -b/(2*a);
    const sy = c - b*b/(4*a);
    const disc = b*b - 4*a*c;
    
    $('w12-sx').textContent = sx.toFixed(2);
    $('w12-sy').textContent = sy.toFixed(2);
    $('w12-ax').textContent = sx.toFixed(2);
    $('w12-disc').textContent = disc.toFixed(2);
    
    const sign = sx >= 0 ? '−' : '+';
    $('w12-canon').textContent = `${a.toFixed(2)}·(x ${sign} ${Math.abs(sx).toFixed(2)})² + (${sy.toFixed(2)})`;
    
    if (disc > 1e-6) {
      const r1 = (-b - Math.sqrt(disc))/(2*a);
      const r2 = (-b + Math.sqrt(disc))/(2*a);
      $('w12-roots').textContent = `Racines : x = ${r1.toFixed(2)} et x = ${r2.toFixed(2)}`;
    } else if (Math.abs(disc) < 1e-6) {
      $('w12-roots').textContent = `Racine double : x = ${sx.toFixed(2)}`;
    } else {
      $('w12-roots').textContent = `Pas de racine réelle (Δ < 0)`;
    }
    
    const N = 150;
    let pts = [];
    for (let i = 0; i <= N; i++) {
      const x = -10 + 20*i/N;
      const y = a*x*x + b*x + c;
      if (Math.abs(y) < 50) pts.push(`${x},${-y}`);
    }
    let s = `<polyline points="${pts.join(' ')}" fill="none" stroke="#534AB7" stroke-width="0.1"/>`;
    if (sx >= -10 && sx <= 10) {
      s += `<line x1="${sx}" y1="-7" x2="${sx}" y2="7" stroke="#993C1D" stroke-width="0.05" stroke-dasharray="0.2 0.15"/>`;
    }
    if (sy >= -7 && sy <= 7 && sx >= -10 && sx <= 10) {
      s += `<circle cx="${sx}" cy="${-sy}" r="0.2" fill="#993C1D"/>`;
      s += `<text x="${sx+0.3}" y="${-sy-0.3}" font-size="0.55" fill="#993C1D" font-weight="500">S</text>`;
    }
    $('w12-parab').innerHTML = s;
  }
  ['a','b','c'].forEach(id => $('w12-'+id).addEventListener('input', update));
  update();
}
