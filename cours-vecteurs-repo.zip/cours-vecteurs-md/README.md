# Géométrie vectorielle et produit scalaire

Cours approfondi de Première spécialité mathématiques, niveau cible **MPSI / CPGE**.

## Contenu

- [`cours.md`](cours.md) — cours complet en Markdown (rendu LaTeX natif GitHub)
- [`cours.pdf`](cours.pdf) — version PDF compilée
- [`cours.tex`](cours.tex) — source LaTeX
- [`interactifs/`](interactifs/) — **12 visualisations interactives** (HTML + JS purs, sans dépendance)

## Visualisations interactives

Le dossier `interactifs/` contient un fichier `index.html` regroupant 12 widgets manipulables (souris ou doigt) :

1. Les 4 formules du produit scalaire — preuve visuelle de leur équivalence
2. Bilinéarité — `u·(v+w) = u·v + u·w`
3. Pythagore vectoriel
4. Identité du parallélogramme
5. Inégalité de Cauchy–Schwarz *(ouverture MPSI)*
6. Décomposition orthogonale d'un vecteur
7. Al-Kashi sur un triangle déformable
8. Médiatrice — lieu MA = MB
9. Transformation MA·MB et cercle de diamètre [AB]
10. Droite : équation cartésienne, projeté orthogonal, distance
11. Cercle — forme canonique
12. Parabole — sommet et axe

**Pour les tester en local :**

```bash
cd interactifs
python3 -m http.server 8000
# ouvre http://localhost:8000
```

**Pour les héberger sur GitHub Pages :**

1. Settings → Pages → Source → main branch
2. Accède à `https://<user>.github.io/<repo>/interactifs/`

## Structure du cours

1. Vecteurs : du concret à la structure (espace vectoriel)
2. Produit scalaire : 4 définitions équivalentes + démonstration
3. Orthogonalité, Pythagore vectoriel
4. Formule d'Al-Kashi
5. Transformation MA·MB
6. Géométrie repérée (droites, cercles, paraboles)
7. Méthodes consolidées
8. Pièges classiques
9. Ouvertures MPSI (Cauchy-Schwarz, orthogonal d'un sev)

## Compilation du PDF

```bash
pdflatex cours.tex
pdflatex cours.tex   # 2 passes pour la table des matières
```

## Licence

Usage personnel et pédagogique libre.
